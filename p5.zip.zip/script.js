async function play(choice) {
  const name = document.getElementById("playerName").value || "Player";
  
  const response = await fetch("/api/play", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ name, choice })
  });

  const data = await response.json();

  document.getElementById("result").innerText =
    `${data.player.name} chose ${data.player.choice} | ${data.ai.name} chose ${data.ai.choice} — ${data.result}`;
}

async function resetGame() {
  await fetch("/api/reset");
  document.getElementById("result").innerText = "Game has been reset.";
}