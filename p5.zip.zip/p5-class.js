
class Player {
  constructor(name) {
    this.name = name;
    this.score = 0;
    this.choice = null;
  }

  makeChoice(choice) {
    this.choice = choice;
  }

  incrementScore() {
    this.score += 1;
  }

  reset() {
    this.score = 0;
    this.choice = null;
  }
}

module.exports = { Player };