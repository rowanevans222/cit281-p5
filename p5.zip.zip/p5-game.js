
const { Player } = require('./p5-class');

const choices = ["rock", "paper", "scissors"];
const gameHistory = [];

const aiPlayer = new Player("Computer");

function getRandomChoice() {
  return choices[Math.floor(Math.random() * choices.length)];
}

function playRound(playerName, playerChoice) {
  const player = new Player(playerName);
  player.makeChoice(playerChoice);

  const aiChoice = getRandomChoice();
  aiPlayer.makeChoice(aiChoice);

  let result;

  if (player.choice === aiPlayer.choice) {
    result = "Draw";
  } else if (
    (player.choice === "rock" && aiPlayer.choice === "scissors") ||
    (player.choice === "paper" && aiPlayer.choice === "rock") ||
    (player.choice === "scissors" && aiPlayer.choice === "paper")
  ) {
    result = "Player Wins";
    player.incrementScore();
  } else {
    result = "AI Wins";
    aiPlayer.incrementScore();
  }

  const round = {
    player: { name: player.name, choice: player.choice },
    ai: { name: aiPlayer.name, choice: aiPlayer.choice },
    result
  };

  gameHistory.push(round);

  return round;
}

function getHistory() {
  return gameHistory;
}

function resetGame() {
  aiPlayer.reset();
  gameHistory.length = 0;
}

module.exports = { playRound, getHistory, resetGame };