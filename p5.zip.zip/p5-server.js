
const express = require('express');
const { playRound, getHistory, resetGame } = require('./p5-game');

const app = express();
const PORT = 4000;

app.use(express.json());
app.use(express.static('public'));

app.get('/api/history', (req, res) => {
  res.json(getHistory());
});

app.post('/api/play', (req, res) => {
  const { name, choice } = req.body;
  const result = playRound(name, choice);
  res.json(result);
});

app.get('/api/reset', (req, res) => {
  resetGame();
  res.json({ message: "Game reset" });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});